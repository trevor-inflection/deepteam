from enum import Enum


class RobustnessType(Enum):
    INPUT_OVERRELIANCE = "Input Overreliance"
    HIJACKING = "Hijacking"
