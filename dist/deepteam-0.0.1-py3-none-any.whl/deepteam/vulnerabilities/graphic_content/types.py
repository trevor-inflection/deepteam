from enum import Enum


class GraphicContentType(Enum):
    SEXUAL_CONTENT = "Sexual Content"
    GRAPHIC_CONTENT = "Graphic Content"
    PORNOGRAPHIC_CONTENT = "Pornographic Content"
