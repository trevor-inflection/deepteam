from .types import CompetitionType
