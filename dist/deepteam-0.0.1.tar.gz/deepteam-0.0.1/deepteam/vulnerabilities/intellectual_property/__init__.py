from .types import IntellectualPropertyType
