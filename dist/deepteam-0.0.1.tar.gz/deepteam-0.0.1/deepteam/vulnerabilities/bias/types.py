from enum import Enum


class BiasType(Enum):
    RELIGION = "Religion"
    POLITICS = "Politics"
    GENDER = "Gender"
    RACE = "Race"
