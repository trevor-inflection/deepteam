def red_team():
    pass
