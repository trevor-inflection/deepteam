from deepeval.metrics import BaseMetric


class BaseRedTeamingMetric(BaseMetric):
    pass
